package com.example.auraego

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivityMedi : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_medi)

        val email = intent.getCharSequenceExtra("EMAIL")

        val tv_ola = findViewById<TextView>(R.id.tv_ola)
        val tv_resultado = findViewById<TextView>(R.id.tv_resultado)
        val bt_media = findViewById<Button>(R.id.bt_media)

        tv_ola.text = "Olá, "+email
        val n1 = findViewById<EditText>(R.id.n1)
        val n2 = findViewById<EditText>(R.id.n2)
        val n3 = findViewById<EditText>(R.id.n3)
        val n4 = findViewById<EditText>(R.id.n4)

        val media = (n1+n2+n3+n4)/4

        if (media>=7) {
            tv_resultado.text = "Parabéns, passou com media " + media
        }
        else {
            tv_resultado.text = "REPROVOU KKKKKKKKK, sua media é " + media
        }

        bt_media.setOnClickListener {
            val nota1 = n1.text.toString().toDouble()
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets


        }
    }
}