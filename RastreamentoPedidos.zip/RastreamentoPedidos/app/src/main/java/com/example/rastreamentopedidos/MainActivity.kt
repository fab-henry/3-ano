package com.example.rastreamentopedidos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val edtCodigo = findViewById<EditText>(R.id.edtCodigo)
        val btnAvancar = findViewById<Button>(R.id.btnAvancar)

        btnAvancar.setOnClickListener {

            if (edtCodigo.text.toString().isEmpty()) {

                Toast.makeText(
                    this,
                    "Digite um código",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                val intent =
                    Intent(this, TermosActivity::class.java)

                intent.putExtra(
                    "codigoPedido",
                    edtCodigo.text.toString()
                )

                startActivity(intent)
            }
        }
    }
}