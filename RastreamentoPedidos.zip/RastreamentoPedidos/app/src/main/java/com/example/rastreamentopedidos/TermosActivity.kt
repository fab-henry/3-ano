package com.example.rastreamentopedidos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TermosActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_termos)

        val codigoPedido =
            intent.getStringExtra("codigoPedido")

        val cbAceito =
            findViewById<CheckBox>(R.id.cbAceito)

        val btnContinuar =
            findViewById<Button>(R.id.btnContinuar)

        btnContinuar.setOnClickListener {

            if (!cbAceito.isChecked) {

                Toast.makeText(
                    this,
                    "Você deve aceitar os termos",
                    Toast.LENGTH_SHORT
                ).show()

            } else {

                val intent =
                    Intent(
                        this,
                        RastreamentoActivity::class.java
                    )

                intent.putExtra(
                    "codigoPedido",
                    codigoPedido
                )

                startActivity(intent)
            }
        }
    }
}