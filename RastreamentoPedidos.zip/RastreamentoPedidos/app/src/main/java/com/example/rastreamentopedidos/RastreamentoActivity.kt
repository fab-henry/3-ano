package com.example.rastreamentopedidos

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class RastreamentoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_rastreamento)

        val codigoPedido =
            intent.getStringExtra("codigoPedido")

        val txtPedido =
            findViewById<TextView>(R.id.txtPedido)

        txtPedido.text =
            "ID PEDIDO: $codigoPedido"
    }
}