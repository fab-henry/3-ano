function cadastrarUsuario() {
    let nome = document.getElementById("nome").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let senha = document.getElementById("senha").value;
    let confirmacaoSenha = document.getElementById("confirmacaoSenha").value;

    let mensagem = document.getElementById("mensagem");

    if(nome === "" || email === "" || telefone === "" || senha === "" || confirmacaoSenha === "") {
        mensagem.textContent = "Por favor, preencha todos os campos.";
        mensagem.style.color = "red";
        return;
    }

    else if(senha !== confirmacaoSenha) {
        mensagem.textContent = "As senhas não coincidem.";
        mensagem.style.color = "red";
        return;
    }

    else if(senha.length < 6) {
        mensagem.textContent = "A senha deve conter pelo menos 6 caracteres.";
        mensagem.style.color = "red";
        return;
    }

    else if(!email.includes("@") || !email.includes(".")) {
        mensagem.textContent = "Por favor, insira um email válido.";
        mensagem.style.color = "red";
        return;
    }

    else if(telefone.length < 10) {
        mensagem.textContent = "Por favor, insira um telefone válido.";
        mensagem.style.color = "red";
        return;
    }

    else {
    // Simulação de cadastro bem-sucedido
    mensagem.textContent = "Cadastro realizado com sucesso!";
    mensagem.style.color = "green";
    }
}